/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.epi.jee.controllers;

import edu.epi.jee.dao.ProjectDao;
import edu.epi.jee.dao.StatusDao;
import edu.epi.jee.dao.TaskDao;
import edu.epi.jee.entities.ProjectEntity;
import edu.epi.jee.entities.StatusEntity;
import edu.epi.jee.entities.TaskEntity;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.task.TaskService;
import org.kie.api.task.model.TaskSummary;
import org.kie.remote.client.api.RemoteRestRuntimeEngineBuilder;
import org.kie.remote.client.api.RemoteRestRuntimeEngineFactory;
import org.kie.remote.client.api.RemoteRuntimeEngineFactory;
import org.kie.remote.client.api.exception.RemoteApiException;
import org.kie.services.client.api.command.RemoteRuntimeEngine;

/**
 *
 * @author HLOL
 */
public class TaskController {

@EJB
private TaskDao taskService1 ;
@EJB
private StatusDao statusService ;
	@EJB
	private ProjectDao workService ; 
	private List<TaskEntity>listTasks;
	private List<StatusEntity> listStatus ; 
	private ProjectEntity work;
	private List<ProjectEntity> listWorks ;
	private List<ProjectEntity> filterWork ;
	private ProjectEntity selectedWork ;
	private  URL instanceurl;
	private  String deploymentId = "com.soarco:SoarcoWorkflow:1.0";
	private  String user = "admin";
	private  String password = "admin";
	private  String processID = "SoarcoWorkflow.workflowSoarco";
	private  RemoteRuntimeEngine engine;
	private TaskSummary selectedtask = null;
	private String taskUserId ; 
	private TaskService taskService =null;
	private List<TaskSummary> tasks ; 
	private int activeIndex ;
	private int newtasksfound ;
	private  KieSession ksession;
	private boolean showStart  = false;
	private boolean showProgress  = false ;
	private boolean showcomplete  = false;
	 private int progress;
	@PostConstruct
	public void init() {
		listWorks= workService.findAllProjects();
	
        listStatus = statusService.findAllEntities();
        listTasks = taskService1.findAllTasks();
    
        setup();
		 initRemoteRuntimeEngineF();
		 
		  ksession = engine.getKieSession();
			 taskService = engine.getTaskService();
                    taskUserId = "admin";
		taskService = engine.getTaskService();
		 tasks = taskService.getTasksAssignedAsPotentialOwner(taskUserId,"");
   
		
		 TaskEntity t1 = new TaskEntity("task1",1,"convention");
		 TaskEntity t2 = new TaskEntity("task2",2,"planing");
		 TaskEntity t3 = new TaskEntity("task3",3,"confirmation");
		 TaskEntity t4 = new TaskEntity("task4",4,"associate the users");
		 TaskEntity t5 = new TaskEntity("task5",5,"work in progress");
		 TaskEntity t6 = new TaskEntity("task6",6,"terminated work");
		 taskService1.create(t1);
		 taskService1.create(t2);
		 taskService1.create(t3);
		 taskService1.create(t4);
		 taskService1.create(t5);
		 taskService1.create(t6);
		 StatusEntity s1 = new StatusEntity("start","yellow",1);
		 StatusEntity s2 = new StatusEntity("inprogress","green",2);
		 StatusEntity s3 = new StatusEntity("complete","red",3);
		 statusService.create(s1);
		 statusService.create(s2); 
		 statusService.create(s3);
		
		 ProjectEntity w1 =  new ProjectEntity("w1",null ,null, "w1", 0);
		 ProjectEntity w2 =  new ProjectEntity("w2",null ,null, "w2",0);
		 ProjectEntity w3 =  new ProjectEntity("w3",null ,null, "w3",0);
		 ProjectEntity w4 =  new ProjectEntity("w4",null ,null, "w4",0);
		 workService.create(w1);
		 workService.create(w2);
		 workService.create(w3);
		 workService.create(w4);
		

	}
	
	public ProjectDao getWorkService() {
		return workService;
	}

	public void setWorkService(ProjectDao workService) {
		this.workService = workService;
	}

	public ProjectEntity getWork() {
		return work;
	}

	public void setWork(ProjectEntity work) {
		this.work = work;
	}

	public List<ProjectEntity> getListWorks() {
		return listWorks;
	}

	public void setListWorks(List<ProjectEntity> listWorks) {
		this.listWorks = listWorks;
	}

	public List<ProjectEntity> getFilterWork() {
		return filterWork;
	}

	public void setFilterWork(List<ProjectEntity> filterWork) {
		this.filterWork = filterWork;
	}

	public ProjectEntity getSelectedWork() {
		return selectedWork;
	}

	public void setSelectedWork(ProjectEntity selectedWork) {
		this.selectedWork = selectedWork;
	}

	public List<TaskEntity> getListTasks() {
		return listTasks;
	}

	public void setListTasks(List<TaskEntity> listTasks) {
		this.listTasks = listTasks;
	}

	public List<StatusEntity> getListStatus() {
		return listStatus;
	}

	public void setListStatus(List<StatusEntity> listStatus) {
		this.listStatus = listStatus;
	}

	
	public TaskSummary getSelectedtask() {
		return selectedtask;
	}

	public void setSelectedtask(TaskSummary selectedtask) {
		this.selectedtask = selectedtask;
	}

	public int getActiveIndex() {
		return activeIndex;
	}

	public void setActiveIndex(int activeIndex) {
		this.activeIndex = activeIndex;
	}

	public boolean isShowStart() {
		return showStart;
	}

	public void setShowStart(boolean showStart) {
		this.showStart = showStart;
	}

	public boolean isShowProgress() {
		return showProgress;
	}

	public void setShowProgress(boolean showProgress) {
		this.showProgress = showProgress;
	}

	public boolean isShowcomplete() {
		return showcomplete;
	}

	public void setShowcomplete(boolean showcomplete) {
		this.showcomplete = showcomplete;
	}

	public  void setup() {

		try {
			instanceurl = new URL("http://localhost:8080/jbpm-console/");
		} catch (MalformedURLException e)
		{
			e.printStackTrace();
			
		}}
		public  void initRemoteRuntimeEngineF() {

			RemoteRestRuntimeEngineBuilder restEngineBuilder = RemoteRuntimeEngineFactory
					.newRestBuilder().addDeploymentId(deploymentId)
					.addUrl(instanceurl).addUserName(user).addPassword(password);

			RemoteRestRuntimeEngineFactory engineFactory = restEngineBuilder
					.buildFactory();
			
			engine = engineFactory.newRuntimeEngine();

		}

		public void startWork()
		{
			setup();
		 initRemoteRuntimeEngineF();
		 
		  ksession = engine.getKieSession();
        taskUserId = "admin";
				try {
					ProcessInstance processInstance =ksession.startProcess(processID);
						System.out.println("----------"+processInstance.getId());
						selectedWork.setCodeProcess(""+processInstance.getId());
					//	selectedWork.setNumtask(0);
						workService.update(selectedWork);
						long procId=processInstance.getId() ;
						//String taskUserId = "admin";
						taskService = engine.getTaskService();
					 tasks = taskService
								.getTasksAssignedAsPotentialOwner(taskUserId,"");
						
						listWorks= workService.findAllProjects();
						showStart = false;
					showcomplete = true ;
					showProgress = true ;
				} catch (RemoteApiException remoteException) {
					remoteException.printStackTrace();
				}}
		public String onStart()
		{
			//taskService = engine.getTaskService();
			List<TaskSummary> tasks = taskService
					.getTasksAssignedAsPotentialOwner(taskUserId,"");		
			for (TaskSummary task : tasks) {
			if (task.getProcessInstanceId() == Integer.parseInt(selectedWork.getCodeProcess()))
			{
					selectedtask = task;
					
	
			taskService.start(selectedtask.getId(), taskUserId);
			System.out.println("...........taskName............."+selectedtask.getName());
			System.out.println("...........taskStatus............"+task.getStatusId());
			activeIndex = taskService1.findTaskByName(task.getName()).getNumber();
			
		}}
			showStart = true;
			showcomplete = true ;
			showProgress = false ;
			
			return null ;
		}
	    public String inprogressTask() {
	    

			//taskService = engine.getTaskService();
	    	/*
			List<TaskSummary> tasks = taskService
					.getTasksAssignedAsPotentialOwner(taskUserId,"");		
			for (TaskSummary task : tasks) {
			if (task.getProcessInstanceId() == Long.parseLong(selectedWork.getCodeprocess()))
			{
					selectedtask = task;
					
	
			taskService.release(selectedtask.getId(), taskUserId);
			System.out.println("...........taskName............."+selectedtask.getName());
			System.out.println("...........taskStatus............"+selectedtask.getStatusId());
			activeIndex = taskService1.findTaskByName(task.getName()).getNumber();
			
		}}*/
			showStart = true;
			showcomplete = false ;
			showProgress =  true;
			
	  System.out.println("*************************"+activeIndex);
	  return null ;
	    }
	    public String completeTask() {
	  
	    	if(tasks !=null)
	    	{
			for (TaskSummary task : tasks) {
		if (task.getProcessInstanceId() == Long.parseLong(selectedWork.getCodeProcess())) {
					selectedtask = task;
					System.out.println("......................."+task.getName());
					//taskService.start(selectedtask.getId(), taskUserId);
					taskService.complete(selectedtask.getId(), taskUserId, null);
					System.out.println("..........task status.............."+selectedtask.getStatusId());
					System.out.println("+++++++++++++++++++++++++++++");

					tasks = taskService.getTasksAssignedAsPotentialOwner(taskUserId,
							"en-UK");
				//	 newtasksfound = tasks != null ? tasks.size() : 0;
				
				//	assertEquals(newtasksfound, tasksfound - 1);
			//		 System.out.println("....................."+selectedtask.getName());

	//		activeIndex = taskService1.findTaskByName(task.getName()).getNumber();
					selectedWork.setNumTask(activeIndex);
					ProjectEntity w =workService.update(selectedWork);
					System.out.println("!!!!!!!!!!!!!"+w.getNumTask());
			//activeIndex = selectedWork.getNumtask() ; 
			System.out.println("*****************"+activeIndex);
			break;
			
	    }}}
	    	else
	    		System.out.println("is null ....................");
	
	    	System.out.println(".....................-*-*-*-*");
	    	tasks = taskService.getTasksAssignedAsPotentialOwner(taskUserId,
					"en-UK");
	    	showStart = false;
			showcomplete = true ;
			showProgress = true ;
	    return null ;
	    }
	    public void destroyWorld() {
	        addMessage("System Error", "Please try again later.");
	        System.out.println("+++++++++++++++++++++++++++++");
		     System.out.println("+++++++++++++++++++++++++++++");
		     System.out.println("+++++++++++++++++++++++++++++");
		     System.out.println("-------------------------------");
	    	  System.out.println("-------------------------------");
	    	  System.out.println("-------------------------------");
	    }
	     
	    public void addMessage(String summary, String detail) {
	        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, detail);
	        FacesContext.getCurrentInstance().addMessage(null, message);
	    }
	    public int getProgress() {
	    
	          progress =selectedWork.getNumTask()*100/5 ; 
	         
	        return progress;
	    }
	 
    
}
